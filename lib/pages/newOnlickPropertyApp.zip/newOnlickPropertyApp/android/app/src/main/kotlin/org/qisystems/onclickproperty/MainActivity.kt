package org.qisystems.onclickproperty

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
