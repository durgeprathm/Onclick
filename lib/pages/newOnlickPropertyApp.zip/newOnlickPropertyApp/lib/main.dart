 import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:onclickproperty/Model/all_dashboard_property_model.dart';
import 'package:onclickproperty/const/const.dart';
import 'package:onclickproperty/const/material_color_generator.dart';
import 'package:onclickproperty/pages/splash_Screen_Page.dart';
import 'package:onclickproperty/utilities/theme.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MaterialColor primarySwatch = generateMaterialColor(primarycolor);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
            create: (context) => AllDashboardResTopProperty()),
        ChangeNotifierProvider(
            create: (context) => AllDashboardResRentProperty()),
        ChangeNotifierProvider(
            create: (context) => AllDashboardResSellProperty()),
        ChangeNotifierProvider(
            create: (context) => AllDashboardCommRentProperty()),
        ChangeNotifierProvider(
            create: (context) => AllDashboardCommSellProperty()),
        ChangeNotifierProvider(
            create: (context) => AllDashboardProjectTopProperty()),
        ChangeNotifierProvider(
            create: (context) => AllDashboardProjectSellProperty()),
        ChangeNotifierProvider(
            create: (context) => AllDashboardCommTopProperty()),


      ],
      child: MaterialApp(
        title: 'OnClick Property',
        debugShowCheckedModeBanner: false,
        // theme: ThemeData(
        //   backgroundColor: primarycolor,
        //   primarySwatch: primarySwatch,
        //   primaryColor: primarycolor,
        //   accentColor: primarycolor,
        // ),

        theme: theme(),
        // home: IntroductionPage()
        home: SplashScreen(),
      ),
    );
  }
}
