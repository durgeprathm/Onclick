import 'package:flutter/material.dart';
import 'package:onclickproperty/Adaptor/fetch_owner_subscription.dart';
import 'package:onclickproperty/Model/subscription_model.dart';
import 'package:onclickproperty/pages/payment/payment_screen.dart';
import 'package:onclickproperty/pages/subscription/subscription_detail_page.dart';
import 'package:onclickproperty/utilities/constants.dart';
import 'package:onclickproperty/utilities/size_config.dart';

class OwnerSubscriptionTab extends StatefulWidget {
  @override
  _OwnerSubscriptionTabState createState() => _OwnerSubscriptionTabState();
}

class _OwnerSubscriptionTabState extends State<OwnerSubscriptionTab> {
  FetchOwnerSubscription fetchOwnerSubscription = new FetchOwnerSubscription();
  List<Subscriptions> subscriptionList = [];
  int Rowcount;
  bool loader = false;

  getSPdata() async {
    setState(() {
      loader = true;
    });

    var response = await fetchOwnerSubscription.getOwnerSubscription("0");
    var resid = response["resid"];
    List<Subscriptions> templist = [];

    if (resid == 200) {
      int rowcount = response["rowcountowner"];
      if (rowcount > 0) {
        var providersd = response["ownersubscriptionlist"];
        for (var n in providersd) {
          Subscriptions subscriptionList = new Subscriptions(
              n["subscribeid"],
              n["subscribeforwhomid"],
              n["subscribeforwhomname"],
              n["subscribeTitle"],
              n["subscribeSubTitle"],
              n["subscribeRate"],
              n["subscribeExtraVisibility"],
              n["subscribeProfessionalAssistance"],
              n["subscribeBenefits"],
              n["subscribeUniqueFeatures"]);
          templist.add(subscriptionList);
        }

        setState(() {
          subscriptionList = templist;
          Rowcount = rowcount;
          loader = false;
        });
      } else {
        setState(() {
          Rowcount = 0;
          loader = false;
        });
      }
    } else {
      setState(() {
        Rowcount = 0;
        loader = false;
      });
    }
  }

  @override
  void initState() {
    getSPdata();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: loader
            ? Center(child: Container(child: CircularProgressIndicator()))
            : Rowcount > 0
                ? Container(
                    child: Column(
                      children: [
                        Center(
                          child: Text(
                            'Choose your subscription plan',
                            style: subscriptioheadingStyle,
                          ),
                        ),
                        SizedBox(height: SizeConfig.screenHeight * 0.02),
                        Expanded(
                          child: Container(
                            child: ListView.builder(
                              scrollDirection: Axis.vertical,
                              shrinkWrap: true,
                              itemCount: subscriptionList.length,
                              itemBuilder: (BuildContext context, int index) {
                                return makeCard(subscriptionList[index]);
                              },
                            ),
                            // GridView.builder(
                            //     itemCount: subscriptionList.length,
                            //     shrinkWrap: true,
                            //     itemBuilder: (context, index) {
                            //       return Padding(
                            //         padding: const EdgeInsets.all(5.0),
                            //         child: Material(
                            //           elevation: 5,
                            //           child: Container(
                            //             child: Padding(
                            //               padding: const EdgeInsets.symmetric(
                            //                   horizontal: 8),
                            //               child: Column(
                            //                 crossAxisAlignment:
                            //                     CrossAxisAlignment.stretch,
                            //                 children: [
                            //                   Center(
                            //                     child: Text(
                            //                       subscriptionList[index]
                            //                           .subscribeTitle,
                            //                       style: subsSubheadingStyle,
                            //                     ),
                            //                   ),
                            //                   Divider(),
                            //                   Center(
                            //                     child: Text(
                            //                       subscriptionList[index]
                            //                           .subscribeRate,
                            //                       style: rateheadingStyle,
                            //                     ),
                            //                   ),
                            //                   Center(
                            //                     child: Text(subscriptionList[index]
                            //                         .subscribeSubTitle),
                            //                   ),
                            //                   SizedBox(
                            //                     height: 5,
                            //                   ),
                            //                   Text(
                            //                     'Extra Visibility:',
                            //                     style: TextStyle(
                            //                         color: Colors.black54,
                            //                         fontWeight: FontWeight.bold),
                            //                   ),
                            //                   Text(subscriptionList[index]
                            //                       .subscribeExtraVisibility),
                            //                   SizedBox(
                            //                     height: 2,
                            //                   ),
                            //                   Text(
                            //                     'Professional Assistance:',
                            //                     style: TextStyle(
                            //                         color: Colors.black54,
                            //                         fontWeight: FontWeight.bold),
                            //                   ),
                            //                   Text(subscriptionList[index]
                            //                       .subscribeProfessionalAssistance),
                            //                   SizedBox(
                            //                     height: 5,
                            //                   ),
                            //                   Padding(
                            //                     padding: const EdgeInsets.symmetric(
                            //                         vertical: 8.0, horizontal: 10),
                            //                     child: SizedBox(
                            //                       width: double.infinity,
                            //                       height:
                            //                           getProportionateScreenHeight(
                            //                               40),
                            //                       child: FlatButton(
                            //                         shape: RoundedRectangleBorder(
                            //                             borderRadius:
                            //                                 BorderRadius.circular(
                            //                                     5)),
                            //                         color: kPrimaryColor,
                            //                         onPressed: () {},
                            //                         child: Text(
                            //                           'GET STARTED',
                            //                           style: TextStyle(
                            //                             fontSize:
                            //                                 getProportionateScreenWidth(
                            //                                     16),
                            //                             color: Colors.white,
                            //                           ),
                            //                         ),
                            //                       ),
                            //                     ),
                            //                   ),
                            //                 ],
                            //               ),
                            //             ),
                            //           ),
                            //         ),
                            //       );
                            //     },
                            //     gridDelegate:
                            //         SliverGridDelegateWithFixedCrossAxisCount(
                            //       crossAxisCount: 2,
                            //       childAspectRatio: 0.5,
                            //     )),
                          ),
                        ),
                      ],
                    ),
                  )
                : Center(
                    child: Container(
                        child: Text("Not available at your location."))),
      ),
    );
  }

  Card makeCard(Subscriptions subscription) => Card(
        elevation: 8.0,
        margin: new EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
        child: Container(
          child: makeListTile(subscription),
        ),
      );

  ListTile makeListTile(Subscriptions subscription) => ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
        title: Text(
          subscription.subscribeTitle,
          style: subsSubheadingStyle,
        ),
        subtitle: Row(
          children: <Widget>[
            Expanded(
              flex: 4,
              child: Padding(
                  padding: EdgeInsets.only(left: 10.0),
                  child: Text(subscription.subscribeSubTitle,
                      style: TextStyle(color: Colors.black))),
            ),

          ],
        ),
        trailing: Column(
          children: [
            Text(subscription.subscribeRate, style: rateheadingStyle),
            Expanded(
              child: FlatButton(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5)),
                color: kPrimaryColor,
                onPressed: () {
                  print('FlatButton');
                  // Navigator.of(context).push(
                  //   MaterialPageRoute(builder: (_) {
                  //     return PaymentScreen();
                  //   }),
                  // );
                },
                child: Text(
                  'Subscribe',
                  style: TextStyle(
                    fontSize: getProportionateScreenWidth(15),
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
        // Icon(Icons.keyboard_arrow_right, color: Colors.white, size: 30.0),
        onTap: () {
          print('onTap');
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) {
              return SubscriptionDetailPage(subscription,'owner');
            }),
          );

        },
      );
}
