class FurnitureProducts{
  int _Furnitureid;
  int _Furnitureuid;
  int _Furnituretypeid;
  String _Furnituretypename;
  String _FurnitureSubTypename;
  String _FurnitureCondition;
  String _FurniturnBrand;
  String _FurniturnTitle;
  String _FurniturnPrice;
  String _FurniturnMobileNumber;
  String _FurniturnUserName;
  String _FurniturnEmail;
  String _FurniturnPincode;
  String _FurniturnCity;
  String _FurniturnArea;
  String _FurniturnYouAre;
  String _FurniturnMaterial;
  String _FurniturnModel;
  String _FurniturnQuntity;
  String _FurniturnDescription;
  String _FurniturnDate;
  String _FurniturnFirstImage;
  String _FurniturnImages;
  String _FurniturnApprove;

  String _FurniturnAlternateno;
  String _FurniturnStd;
  String _FurnitueTelephone;

  String _FurniturnLat;
  String _FurniturnLong;

  FurnitureProducts(
  this._Furnitureid,
  this. _Furnitureuid,
  this. _Furnituretypeid,
  this. _Furnituretypename,
  this. _FurnitureSubTypename,
  this. _FurnitureCondition,
  this. _FurniturnBrand,
  this. _FurniturnTitle,
  this. _FurniturnPrice,
  this. _FurniturnMobileNumber,
  this. _FurniturnUserName,
  this. _FurniturnEmail,
  this. _FurniturnPincode,
  this. _FurniturnCity,
  this. _FurniturnArea,
  this. _FurniturnYouAre,
  this. _FurniturnMaterial,
  this. _FurniturnModel,
  this. _FurniturnQuntity,
  this. _FurniturnDescription,
  this. _FurniturnAlternateno,
  this. _FurniturnStd,
  this. _FurnitueTelephone,
  this. _FurniturnDate,
  this._FurniturnLat,
  this._FurniturnLong,
  this. _FurniturnFirstImage,
  this. _FurniturnImages,
  );

  FurnitureProducts.userposted(
      this._Furnitureid,
      this. _FurniturnBrand,
      this._FurniturnPrice,
      this. _FurniturnMaterial,
      this. _Furnituretypeid,
      this. _Furnituretypename,
      this._FurniturnApprove,
      this. _FurniturnImages,
      );

  String get EFurniturnImages => _FurniturnImages;

  set EFurniturnImages(String value) {
    _FurniturnImages = value;
  }

  String get FurniturnFirstImage => _FurniturnFirstImage;

  set FurniturnFirstImage(String value) {
    _FurniturnFirstImage = value;
  }

  String get FurniturnDate => _FurniturnDate;

  set FurniturnDate(String value) {
    _FurniturnDate = value;
  }

  String get FurniturnDescription => _FurniturnDescription;

  set FurniturnDescription(String value) {
    _FurniturnDescription = value;
  }

  String get FurniturnQuntity => _FurniturnQuntity;

  set FurniturnQuntity(String value) {
    _FurniturnQuntity = value;
  }

  String get FurniturnModel => _FurniturnModel;

  set FurniturnModel(String value) {
    _FurniturnModel = value;
  }

  String get FurniturnMaterial => _FurniturnMaterial;

  set FurniturnMaterial(String value) {
    _FurniturnMaterial = value;
  }

  String get FurniturnYouAre => _FurniturnYouAre;

  set FurniturnYouAre(String value) {
    _FurniturnYouAre = value;
  }

  String get FurniturnArea => _FurniturnArea;

  set FurniturnArea(String value) {
    _FurniturnArea = value;
  }

  String get FurniturnCity => _FurniturnCity;

  set FurniturnCity(String value) {
    _FurniturnCity = value;
  }

  String get FurniturnPincode => _FurniturnPincode;

  set FurniturnPincode(String value) {
    _FurniturnPincode = value;
  }

  String get FurniturnEmail => _FurniturnEmail;

  set FurniturnEmail(String value) {
    _FurniturnEmail = value;
  }

  String get FurniturnUserName => _FurniturnUserName;

  set FurniturnUserName(String value) {
    _FurniturnUserName = value;
  }

  String get FurniturnMobileNumber => _FurniturnMobileNumber;

  set FurniturnMobileNumber(String value) {
    _FurniturnMobileNumber = value;
  }

  String get FurniturnPrice => _FurniturnPrice;

  set FurniturnPrice(String value) {
    _FurniturnPrice = value;
  }

  String get FurniturnTitle => _FurniturnTitle;

  set FurniturnTitle(String value) {
    _FurniturnTitle = value;
  }

  String get FurniturnBrand => _FurniturnBrand;

  set FurniturnBrand(String value) {
    _FurniturnBrand = value;
  }

  String get FurnitureCondition => _FurnitureCondition;

  set FurnitureCondition(String value) {
    _FurnitureCondition = value;
  }

  String get FurnitureSubTypename => _FurnitureSubTypename;

  set FurnitureSubTypename(String value) {
    _FurnitureSubTypename = value;
  }

  String get Furnituretypename => _Furnituretypename;

  set Furnituretypename(String value) {
    _Furnituretypename = value;
  }

  int get Furnituretypeid => _Furnituretypeid;

  set Furnituretypeid(int value) {
    _Furnituretypeid = value;
  }

  int get Furnitureuid => _Furnitureuid;

  set Furnitureuid(int value) {
    _Furnitureuid = value;
  }

  int get Furnitureid => _Furnitureid;

  set Furnitureid(int value) {
    _Furnitureid = value;
  }

  String get FurniturnApprove => _FurniturnApprove;

  set FurniturnApprove(String value) {
    _FurniturnApprove = value;
  }

  String get FurnitueTelephone => _FurnitueTelephone;

  set FurnitueTelephone(String value) {
    _FurnitueTelephone = value;
  }

  String get FurniturnStd => _FurniturnStd;

  set FurniturnStd(String value) {
    _FurniturnStd = value;
  }

  String get FurniturnAlternateno => _FurniturnAlternateno;

  set FurniturnAlternateno(String value) {
    _FurniturnAlternateno = value;
  }

  String get FurniturnImages => _FurniturnImages;

  set FurniturnImages(String value) {
    _FurniturnImages = value;
  }

  String get FurniturnLong => _FurniturnLong;

  set FurniturnLong(String value) {
    _FurniturnLong = value;
  }

  String get FurniturnLat => _FurniturnLat;

  set FurniturnLat(String value) {
    _FurniturnLat = value;
  }
}
