class UpdatedAgent {
  String _id;
  String _uid;
  String _CompanyName;
  String _Companymobileno;
  String _CompanyAlternetmobie;
  String _CompanyStd;
  String _Companytelephone;
  String _CompanyEmail;
  String _CompanyLocation;
  String _CompanyCity;
  String _Companylat;
  String _Companylong;
  String _CompanyDescription;
  String _CompanyAddreess;
  String _CompanyPincode;
  String _Companyyear;
  String _CompanyNoEmp;
  String _CompanyWebsite;
  String _name;
  String _mobileno;
  String _alternateno;
  String _std;
  String _telephoneno;
  String _email;
  String _city;
  String _pincode;
  String _servclocation;
  String _lat;
  String _long;
  String _address;
  String _bankname;
  String _rateofinterest;
  String _loantype;
  String _date;
  String _approve;
  String _Image;
  String _Description;
  String _category;
  String _registertype;
  String _provdcustomrlocat;

  UpdatedAgent.Loan(
      this._id,
      this._uid,
      this._CompanyName,
      this._Companymobileno,
      this._CompanyAlternetmobie,
      this._CompanyStd,
      this._Companytelephone,
      this._CompanyEmail,
      this._CompanyLocation,
      this._CompanyCity,
      this._Companylat,
      this._Companylong,
      this._CompanyDescription,
      this._CompanyAddreess,
      this._CompanyPincode,
      this._Companyyear,
      this._CompanyNoEmp,
      this._CompanyWebsite,
      this._name,
      this._mobileno,
      this._alternateno,
      this._std,
      this._telephoneno,
      this._email,
      this._city,
      this._pincode,
      this._servclocation,
      this._lat,
      this._long,
      this._address,
      this._bankname,
      this._rateofinterest,
      this._loantype,
      this._date,
      this._approve,
      this._Image);

  UpdatedAgent.Rent(
      this._id,
      this._uid,
      this._CompanyName,
      this._Companymobileno,
      this._CompanyAlternetmobie,
      this._CompanyStd,
      this._Companytelephone,
      this._CompanyEmail,
      this._CompanyLocation,
      this._CompanyCity,
      this._Companylat,
      this._Companylong,
      this._CompanyDescription,
      this._CompanyAddreess,
      this._CompanyPincode,
      this._Companyyear,
      this._CompanyNoEmp,
      this._CompanyWebsite,
      this._name,
      this._mobileno,
      this._alternateno,
      this._std,
      this._telephoneno,
      this._email,
      this._city,
      this._pincode,
      this._servclocation,
      this._lat,
      this._long,
      this._address,
      this._Description,
      this._category,
      this._registertype,
      this._provdcustomrlocat,
      this._date,
      this._approve,
      this._Image);

  String get approve => _approve;

  set approve(String value) {
    _approve = value;
  }

  String get date => _date;

  set date(String value) {
    _date = value;
  }

  String get loantype => _loantype;

  set loantype(String value) {
    _loantype = value;
  }

  String get rateofinterest => _rateofinterest;

  set rateofinterest(String value) {
    _rateofinterest = value;
  }

  String get bankname => _bankname;

  set bankname(String value) {
    _bankname = value;
  }

  String get address => _address;

  set address(String value) {
    _address = value;
  }

  String get long => _long;

  set long(String value) {
    _long = value;
  }

  String get lat => _lat;

  set lat(String value) {
    _lat = value;
  }

  String get servclocation => _servclocation;

  set servclocation(String value) {
    _servclocation = value;
  }

  String get pincode => _pincode;

  set pincode(String value) {
    _pincode = value;
  }

  String get city => _city;

  set city(String value) {
    _city = value;
  }

  String get email => _email;

  set email(String value) {
    _email = value;
  }

  String get telephoneno => _telephoneno;

  set telephoneno(String value) {
    _telephoneno = value;
  }

  String get alternateno => _alternateno;

  set alternateno(String value) {
    _alternateno = value;
  }

  String get mobileno => _mobileno;

  set mobileno(String value) {
    _mobileno = value;
  }

  String get name => _name;

  set name(String value) {
    _name = value;
  }

  String get CompanyWebsite => _CompanyWebsite;

  set CompanyWebsite(String value) {
    _CompanyWebsite = value;
  }

  String get CompanyNoEmp => _CompanyNoEmp;

  set CompanyNoEmp(String value) {
    _CompanyNoEmp = value;
  }

  String get Companyyear => _Companyyear;

  set Companyyear(String value) {
    _Companyyear = value;
  }

  String get CompanyPincode => _CompanyPincode;

  set CompanyPincode(String value) {
    _CompanyPincode = value;
  }

  String get CompanyAddreess => _CompanyAddreess;

  set CompanyAddreess(String value) {
    _CompanyAddreess = value;
  }

  String get CompanyDescription => _CompanyDescription;

  set CompanyDescription(String value) {
    _CompanyDescription = value;
  }

  String get Companylong => _Companylong;

  set Companylong(String value) {
    _Companylong = value;
  }

  String get Companylat => _Companylat;

  set Companylat(String value) {
    _Companylat = value;
  }

  String get CompanyCity => _CompanyCity;

  set CompanyCity(String value) {
    _CompanyCity = value;
  }

  String get CompanyLocation => _CompanyLocation;

  set CompanyLocation(String value) {
    _CompanyLocation = value;
  }

  String get CompanyEmail => _CompanyEmail;

  set CompanyEmail(String value) {
    _CompanyEmail = value;
  }

  String get Companytelephone => _Companytelephone;

  set Companytelephone(String value) {
    _Companytelephone = value;
  }

  String get CompanyAlternetmobie => _CompanyAlternetmobie;

  set CompanyAlternetmobie(String value) {
    _CompanyAlternetmobie = value;
  }

  String get Companymobileno => _Companymobileno;

  set Companymobileno(String value) {
    _Companymobileno = value;
  }

  String get CompanyName => _CompanyName;

  set CompanyName(String value) {
    _CompanyName = value;
  }

  String get uid => _uid;

  set uid(String value) {
    _uid = value;
  }

  String get id => _id;

  set id(String value) {
    _id = value;
  }

  String get Image => _Image;

  set Image(String value) {
    _Image = value;
  }

  String get provdcustomrlocat => _provdcustomrlocat;

  set provdcustomrlocat(String value) {
    _provdcustomrlocat = value;
  }

  String get registertype => _registertype;

  set registertype(String value) {
    _registertype = value;
  }

  String get category => _category;

  set category(String value) {
    _category = value;
  }

  String get Description => _Description;

  set Description(String value) {
    _Description = value;
  }

  String get std => _std;

  set std(String value) {
    _std = value;
  }

  String get CompanyStd => _CompanyStd;

  set CompanyStd(String value) {
    _CompanyStd = value;
  }
}
